$(document).ready(function () {
    $('.menu .item').tab();
    $('.ui.accordion').accordion();
    $('.content.example .ui.embed').embed();
});

